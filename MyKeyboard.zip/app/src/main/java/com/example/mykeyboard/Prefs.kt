package com.example.mykeyboard

import android.content.Context
import org.json.JSONArray

object C {
    val BG = 0xFF202124.toInt()
    val BAR = 0xFF2A2B2E.toInt()
    val KEY = 0xFF3C4043.toInt()
    val KEY_DOWN = 0xFF5F6368.toInt()
    val SPECIAL = 0xFF2F3033.toInt()
    val ACCENT = 0xFF34A853.toInt()
    val ACCENT_DOWN = 0xFF2D8F46.toInt()
    val TEXT = 0xFFE8EAED.toInt()
    val TEXT_DIM = 0xFF9AA0A6.toInt()
}

class Prefs(context: Context) {
    private val sp = context.applicationContext
        .getSharedPreferences("serame_prefs", Context.MODE_PRIVATE)

    var keyHeight: Int
        get() = sp.getInt("keyHeight", 46)
        set(v) { sp.edit().putInt("keyHeight", v).apply() }

    // 0 off, 1 light, 2 medium, 3 strong
    var vibration: Int
        get() = sp.getInt("vibration", 1)
        set(v) { sp.edit().putInt("vibration", v).apply() }

    var sound: Boolean
        get() = sp.getBoolean("sound", false)
        set(v) { sp.edit().putBoolean("sound", v).apply() }

    var autoCap: Boolean
        get() = sp.getBoolean("autoCap", true)
        set(v) { sp.edit().putBoolean("autoCap", v).apply() }

    // 0 off, 1 left, 2 right
    var oneHanded: Int
        get() = sp.getInt("oneHanded", 0)
        set(v) { sp.edit().putInt("oneHanded", v).apply() }

    var shortcuts: String
        get() = sp.getString("shortcuts", "omw=on my way\nbrb=be right back\nidk=I don't know") ?: ""
        set(v) { sp.edit().putString("shortcuts", v).apply() }

    var clips: List<String>
        get() = try {
            val a = JSONArray(sp.getString("clips", "[]"))
            List(a.length()) { a.getString(it) }
        } catch (e: Exception) {
            emptyList()
        }
        set(v) { sp.edit().putString("clips", JSONArray(v).toString()).apply() }
}

// Image clips are stored in the clip list as IMG_PREFIX + file name.
const val IMG_PREFIX = "\u0001IMG:"

fun isImageClip(s: String) = s.startsWith(IMG_PREFIX)

fun imageNameOf(s: String) = s.removePrefix(IMG_PREFIX)

fun clearClipFiles(context: Context) {
    java.io.File(context.filesDir, "clips").deleteRecursively()
}
