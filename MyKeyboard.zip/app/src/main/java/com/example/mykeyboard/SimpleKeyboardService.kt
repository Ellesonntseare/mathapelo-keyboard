package com.example.mykeyboard

import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.InputType
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.LinearLayout

class SimpleKeyboardService : InputMethodService() {

    private companion object {
        const val OFF = 0
        const val ONCE = 1
        const val CAPS = 2
    }

    private lateinit var root: LinearLayout
    private val letterKeys = mutableListOf<Pair<Button, Char>>()
    private var shiftButton: Button? = null

    private var shift = OFF
    private var lastShiftTap = 0L
    private var symbols = false

    private val handler = Handler(Looper.getMainLooper())

    private val numberRow = "1234567890"
    private val letterRows = listOf("qwertyuiop", "asdfghjkl", "zxcvbnm")
    private val symbolRows = listOf("@#$%&-+()/", "*\"':;!?=_")

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()

    // ---------- Setup ----------

    override fun onCreateInputView(): View {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF222222.toInt())
            setPadding(dp(2), dp(4), dp(2), dp(4))
        }
        render()
        return root
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        symbols = false
        shift = OFF
        if (::root.isInitialized) render()
        autoCapitalize()
    }

    // ---------- Drawing the keyboard ----------

    private fun render() {
        root.removeAllViews()
        letterKeys.clear()
        shiftButton = null

        // Number row (always visible)
        root.addView(charRow(numberRow))

        if (symbols) {
            symbolRows.forEach { root.addView(charRow(it)) }
        } else {
            letterRows.forEach { row ->
                val line = rowLayout()
                for (c in row) {
                    val b = key(c.toString(), 1f) { typeLetter(c) }
                    letterKeys.add(b to c)
                    line.addView(b)
                }
                root.addView(line)
            }
        }

        // Bottom row
        val bottom = rowLayout()
        bottom.addView(key(if (symbols) "ABC" else "123", 1.5f) {
            symbols = !symbols
            render()
        })
        if (!symbols) {
            val s = key("⇧", 1.5f) { onShiftTap() }
            shiftButton = s
            bottom.addView(s)
        }
        bottom.addView(key(",", 1f) { commit(",") })
        bottom.addView(key("space", 4f) { commit(" ") })
        bottom.addView(key(".", 1f) { commit(".") })
        bottom.addView(deleteKey())
        bottom.addView(key("⏎", 1.5f) { sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER) })
        root.addView(bottom)

        refreshLetters()
    }

    private fun rowLayout() = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER
    }

    private fun charRow(chars: String): LinearLayout {
        val line = rowLayout()
        for (c in chars) line.addView(key(c.toString(), 1f) { commit(c.toString()) })
        return line
    }

    private fun styledButton(label: String, weight: Float) = Button(this).apply {
        text = label
        isAllCaps = false
        setTextColor(0xFFFFFFFF.toInt())
        setBackgroundColor(0xFF444444.toInt())
        layoutParams = LinearLayout.LayoutParams(0, dp(52), weight).apply {
            setMargins(dp(2), dp(2), dp(2), dp(2))
        }
    }

    private fun key(label: String, weight: Float, onClick: () -> Unit) =
        styledButton(label, weight).apply {
            setOnClickListener {
                it.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                onClick()
            }
        }

    // ---------- Delete with key repeat ----------

    private fun deleteKey(): Button {
        val repeat = object : Runnable {
            override fun run() {
                deleteOne()
                handler.postDelayed(this, 50)
            }
        }
        return styledButton("⌫", 1.5f).apply {
            setOnTouchListener { v, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                        deleteOne()
                        handler.postDelayed(repeat, 400) // wait, then repeat
                        true
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        handler.removeCallbacks(repeat)
                        true
                    }
                    else -> true
                }
            }
        }
    }

    private fun deleteOne() {
        currentInputConnection?.deleteSurroundingText(1, 0)
        autoCapitalize()
    }

    // ---------- Typing ----------

    private fun commit(text: String) {
        currentInputConnection?.commitText(text, 1)
        autoCapitalize()
    }

    private fun typeLetter(c: Char) {
        val out = if (shift != OFF) c.uppercaseChar() else c
        currentInputConnection?.commitText(out.toString(), 1)
        if (shift == ONCE) shift = OFF
        autoCapitalize()
        refreshLetters()
    }

    // ---------- Shift, caps lock, auto-capitalize ----------

    private fun onShiftTap() {
        val now = SystemClock.uptimeMillis()
        shift = when {
            shift == CAPS -> OFF                    // tap again to turn caps lock off
            now - lastShiftTap < 400 -> CAPS        // double tap = caps lock
            shift == OFF -> ONCE
            else -> OFF
        }
        lastShiftTap = now
        refreshLetters()
    }

    private fun autoCapitalize() {
        val info = currentInputEditorInfo ?: return
        if (info.inputType == InputType.TYPE_NULL || shift == CAPS) return
        val mode = currentInputConnection?.getCursorCapsMode(info.inputType) ?: 0
        val wanted = if (mode != 0) ONCE else OFF
        if (shift != wanted) {
            shift = wanted
            refreshLetters()
        }
    }

    private fun refreshLetters() {
        for ((btn, c) in letterKeys) {
            btn.text = if (shift != OFF) c.uppercaseChar().toString() else c.toString()
        }
        shiftButton?.text = when (shift) {
            CAPS -> "⇪"
            ONCE -> "⬆"
            else -> "⇧"
        }
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        super.onFinishInputView(finishingInput)
        handler.removeCallbacksAndMessages(null)
    }
}
